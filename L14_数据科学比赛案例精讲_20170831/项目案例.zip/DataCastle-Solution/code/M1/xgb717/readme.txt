xgb717.py这份代码可能无法复现结果，因为xgb717这个模型主要是为了获得原始特征的重要性，当时得到特征排序文件raw_feature_score.csv后，修改过该模型的参数，
但我保留了xgb717的模型文件，可下载：http://pan.baidu.com/s/1c2snJ9m
